console.log("Contacts.js");
const baseURL = "http://localhost:8081";
const viewContactModal = document.getElementById("view_contact_modal");

// set the modal menu element
// const $targetEl = document.getElementById('modalEl');

// options with default values
const options = {
  placement: 'bottom-right',
  backdrop: 'dynamic',
  backdropClasses: 'bg-gray-900/50 dark:bg-gray-900/80 fixed inset-0 z-40',
  closable: true,
  onHide: () => {
      console.log('modal is hidden');
  },
  onShow: () => {
      console.log('modal is shown');
  },
  onToggle: () => {
      console.log('modal has been toggled');
  }
};

const instanceOptions = {
    id: "view_contact_modal",
    override: true,
};

const contactModal=new Modal(viewContactModal,options,instanceOptions);

function openContactModal(){
    contactModal.show();
}

function closeContactModal(){
    contactModal.hide();
}


async function loadContactdata(id) {
    console.log(id);

    try {
        // 1️⃣ fetch the contact
        const response = await fetch(`${baseURL}/api/contacts/${id}`);

        // 2️⃣ check the response is OK
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        // 3️⃣ parse JSON
        const data = await response.json();
        console.log(data);

        // 4️⃣ put the data into the modal
        document.querySelector('#contact_name').textContent = data.name;
        document.querySelector('#contact_email').textContent = data.email;
        document.querySelector("#contact_image").src = data.picture;
        document.querySelector("#contact_address").textContent = data.address;
        document.querySelector("#contact_phone").textContent = data.phoneNumber;
        document.querySelector("#contact_about").textContent = data.description;
        const contactFavorite = document.querySelector("#contact_favorite");
        if (data.favorite) {
          contactFavorite.innerHTML =
            "<i class='fas fa-star text-yellow-400'></i><i class='fas fa-star text-yellow-400'></i><i class='fas fa-star text-yellow-400'></i><i class='fas fa-star text-yellow-400'></i><i class='fas fa-star text-yellow-400'></i>";
        } else {
          contactFavorite.innerHTML = "Not Favorite Contact";
        }
    
        document.querySelector("#contact_website").href = data.websiteLink;
        document.querySelector("#contact_website").textContent = data.websiteLink;
        document.querySelector("#contact_linkedIn").href = data.linkedInLink;
        document.querySelector("#contact_linkedIn").textContent = data.linkedInLink;
        // add more lines if you have other fields:
        // document.querySelector('#contact_email').textContent = data.email;

        // 5️⃣ show the modal
        openContactModal();
    } catch (error) {
        console.log('Error:', error);
    }
}

//delete contact
 async function deleteContact(id) {
//     Swal.fire({
//         title: "Do you want to delete the contact?",
//         icon : "warning",
//         showCancelButton: true,
//         confirmButtonText: "Delete",
       
//       }).then((result) => {
//         /* Read more about isConfirmed, isDenied below */
//         if (result.isConfirmed) {
//           const url = `http://localhost:8081/api/user/contacts/delete/" +id;
//           window.location.replace(url);
//         }
//       });
//  }
Swal.fire({
    title: "Do you want to delete the contact?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Delete",
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {
      const url = `${baseURL}/user/contacts/delete/` + id;
      window.location.replace(url);
    }
  });
}

