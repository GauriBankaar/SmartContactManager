package com.scm.scm.services;

import java.util.List;

import org.springframework.data.domain.Page;

import com.scm.scm.entities.Contact;
import com.scm.scm.entities.User;

public interface ContactService {


    // Save contact
    Contact save(Contact contact);

    // Update contact
    Contact update(Contact contact);

    // Get all contacts
    List<Contact> getAll();

    // Get contact by ID
    Contact getById(String id);

    // Delete contact
    void delete(String id);

    //search contact
    Page<Contact> searchByName(String nameKeyword,int size,int page,String sortBy,String order,User user);
    Page<Contact> searchByEmail(String emailKeyword,int size,int page,String sortBy,String order,User user);
    Page<Contact> searchByPhoneNumber(String phoneNumberKeyword,int size,int page,String sortBy,String order,User user);

    //get contacts by uerId
    List<Contact> getByUserId(String userId);

    //get contacts by user
    Page<Contact> getByUser(User user,int page,int size,String sortField, String sortDirection);
}
