package com.scm.scm.controllers;

import java.security.Principal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
//import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.scm.scm.entities.User;
import com.scm.scm.helpers.Helper;
import com.scm.scm.services.UserService;


@Controller
@RequestMapping("/user")
//Has protected urls
public class UserController {

    private Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

   
    {

    }


    //user dashboard page
    @RequestMapping(value="/dashboard", method=RequestMethod.GET)
    public String userDashboard() {
        return "user/dashboard";
    }
    //user profile page
    @RequestMapping(value="/profile", method=RequestMethod.GET)
    public String userProfile(Model model, Authentication authentication) {
        // //String name = principal.getName();
         //String username = Helper.getEmailOfLoggedInUser(authentication);
        // //to print the name of the user logged in on console
        // logger.info("User logged in: {}", username);

        // //database se user ki details fetch kar sakte
        // User user = userService.getUserByEmail(username);
        // System.out.println(user.getName());
        // System.out.println(user.getEmail());

        // model.addAttribute("loggedInUser", user);
        return "user/profile";
    }

    // @RequestMapping(value="/direct_message", method=RequestMethod.GET)
    // public String userDirectMessage(Model model, Authentication authentication) {
    //     String username = Helper.getEmailOfLoggedInUser(authentication);
    //     User user = userService.getUserByEmail(username);
    //     model.addAttribute("loggedInUser", user);
    //     return "user/direct_message";
    // }
    
}
