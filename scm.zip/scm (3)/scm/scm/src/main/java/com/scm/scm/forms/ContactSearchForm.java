package com.scm.scm.forms;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactSearchForm {

    public String value;
    public String field;

}
