package com.scm.scm.validators;

import org.springframework.web.multipart.MultipartFile;
import javax.imageio.*;

import java.io.IOException;

import java.awt.image.*;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class FileValidator implements ConstraintValidator<ValidFile, MultipartFile> {

    private static final long MAX_SIZE = 5 * 1024 * 1024; // 5MB

    @Override
    public boolean isValid(MultipartFile file, ConstraintValidatorContext context) {
        
        if(file==null || file.isEmpty()) {
            // context.disableDefaultConstraintViolation();
            // context.buildConstraintViolationWithTemplate("File is required").addConstraintViolation();
            return true; // Not validating empty files, assuming they are valid
        }
        //checking the file size
        if (file.getSize() > MAX_SIZE) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("File size exceeds the maximum limit of 5MB").addConstraintViolation();
            return false;
        }
        //checking the file resolution
        // try {
        //    BufferedImage bufferedImage =  ImageIO.read(file.getInputStream());
        // } catch (IOException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }
        return true; // Valid file type
    }
}
