package com.scm.scm.config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
// import org.springframework.security.core.userdetails.UserDetails;
// import org.springframework.security.core.userdetails.UserDetailsService;
// import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.scm.scm.services.impl.SecurityCustomUserDetailService;

@Configuration
public class SecurityConfig {

    // HAVING HARDCODED VALUES:
    // @Bean
    // public UserDetailsService userDetailsService() {
    
        // UserDetails user1 = User
        //     .withDefaultPasswordEncoder()
        //     .username("admin123")
        //     .password("admin123")
        //     .roles("ADMIN","USER")
        //     .build();

        // UserDetails user2 = User
        //     .withDefaultPasswordEncoder()
        //     .username("user123")
        //     .password("user123")
        //     .build();

        // var inMemoryUserDetailsManager  = new InMemoryUserDetailsManager(user1,user2);
        // return inMemoryUserDetailsManager;

    //configuration of authentication provider spring security

    @Autowired
    private SecurityCustomUserDetailService userDetailService;

    @Autowired
    private OAuthAuthenticationSuccessHandler handler;

    //DATABASE SE USERNAME KO NIKALNA
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        //bring here user detail service ka obj
        daoAuthenticationProvider.setUserDetailsService(userDetailService);
        // bring here password encoder ka obj
        daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());

        return daoAuthenticationProvider;
    }

    //WHICH ROUTES HD HAVE AUTHENTICATION 

    @Bean //ye pages k security sign up nhi karna padega
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        // configuration
        //urls configure kiya hai ki which are public/private
        httpSecurity.authorizeHttpRequests(authorize -> {
             // Permit all static resources
             authorize.requestMatchers(
                "/js/**",
                "/css/**",
                "/images/**",
                "/webjars/**",
                "/favicon.ico"
            ).permitAll();
            // authorize.requestMatchers("/home","/register","/services").permitAll()
            authorize.requestMatchers("/user/**").authenticated();
            authorize.anyRequest().permitAll();
        });

        //form default login
        //agar ham kuch changes karne hue form login s related then yha an hoga
        // httpSecurity.formLogin(Customizer.withDefaults());

        // CUSTOMIZING THE ABVE DEFAULT FORM!
        httpSecurity.formLogin(formLogin -> {
            formLogin.loginPage("/login");
            formLogin.defaultSuccessUrl("/user/profile", true);
            formLogin.loginProcessingUrl("/authenticate");
            // formLogin.successForwardUrl("/user/dashboard");
            // formLogin.failureForwardUrl("/login?error=true");
            // formLogin.defaultSuccessUrl("/home");
            formLogin.usernameParameter("email");
            formLogin.passwordParameter("password");
        });

        //DISABLING THE CSRF PROTECTION FOR NOW
        httpSecurity.csrf(AbstractHttpConfigurer::disable);

        // LOGOUT CONFIGURATION
        httpSecurity.logout(logout -> logout
            .logoutUrl("/do-logout")
            .logoutSuccessUrl("/login?logout=true")
            .invalidateHttpSession(true)
            .clearAuthentication(true)
            .deleteCookies("JSESSIONID")
            // .permitAll()
        );

        //oauth config
        httpSecurity.oauth2Login(oauth2 -> {
            oauth2.loginPage("/login");
            oauth2.successHandler(handler);
            //oauth2.defaultSuccessUrl("/user/dashboard",true);
            // oauth2.failureUrl("/login?error=true");
            // oauth2.userInfoEndpoint(userInfo->{
            //     userInfo.userService(customOAuth2UserService);
            // });
        });

        return httpSecurity.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
