console.log("Script loaded");

