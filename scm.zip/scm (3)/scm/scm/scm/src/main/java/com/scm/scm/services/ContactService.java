package com.scm.scm.services;

import java.util.List;

import com.scm.scm.entities.Contact;

public interface ContactService {


    // Save contact
    Contact save(Contact contact);

    // Update contact
    Contact update(Contact contact);

    // Get all contacts
    List<Contact> getAll();

    // Get contact by ID
    Contact getById(String id);

    // Delete contact
    void delete(String id);

    //search contact
    List<Contact> search(String name,String email,String phoneNumber);

    //get contacts by uerId
    List<Contact> getByUserId(String userId);
}
