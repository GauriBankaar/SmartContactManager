package com.scm.scm.entities;

public enum Providers {

    SELF, GOOGLE, GITHUB
}
