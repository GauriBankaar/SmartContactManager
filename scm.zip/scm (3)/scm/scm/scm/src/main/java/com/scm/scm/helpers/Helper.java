package com.scm.scm.helpers;

import org.springframework.security.core.Authentication;
//import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
//import org.springframework.security.oauth2.core.OAuth2AuthenticatedPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;

public class Helper {

    public static String getEmailOfLoggedInUser(Authentication authentication) {
       // AuthenticationPrincipal principal = (AuthenticationPrincipal)authentication.getPrincipal();
        //agar email is password se login kiya hai to email id mil jayegi
        String username = "";
        if (authentication instanceof OAuth2AuthenticationToken)
        {
        //    var aOAuth2AuthenticationToken =  (OAuth2AuthenticationToken) authentication;
        //    var clientid =  aOAuth2AuthenticationToken.getAuthorizedClientRegistrationId();
        //    var oauth2User = (OAuth2User) authentication.getPrincipal();
        OAuth2AuthenticationToken oauthToken = (OAuth2AuthenticationToken) authentication;
        String clientid = oauthToken.getAuthorizedClientRegistrationId();
        OAuth2User oauth2User = oauthToken.getPrincipal();
          
             //agar google se login kiya hai to email id milegi
           if(clientid.equalsIgnoreCase("google"))
           {
                System.out.println("Google se login kiya hai");
                username = oauth2User.getAttribute("email").toString();
            }
        }
        else
        {
            System.out.println("Username and password se login kiya hai");
            return authentication.getName(); // This will return the email of the user logged in using username and password
        }

       return username; // This will return the email of the user logged in using username and password
       // String email = principal.getName();
       
    
}
}