package com.scm.scm.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.scm.scm.entities.Providers;
import com.scm.scm.entities.User;
import com.scm.scm.forms.UserForm;
import com.scm.scm.helpers.Message;
import com.scm.scm.helpers.MessageType;
import com.scm.scm.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class PageController {
    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index() {
        return "redirect:/home"; // This will resolve to src/main/resources/templates/index.html
    }
    @Controller
    public class TestController {
    @GetMapping("/test")
    public String test() {
        return "test"; 
    }
   }
    @RequestMapping("/home")
    public String home(Model model) {
        System.out.println("home page handler");
        model.addAttribute("name","Substring Tech" );
        model.addAttribute("YTchannel","Girija" );
        model.addAttribute("TPlink","https://www.google.com/search?q=html&rlz=1C1OZZY_enIN1134IN1135&oq=ht&gs_lcrp=EgZjaHJvbWUqCggBEAAYsQMYgAQyBggAEEUYOTIKCAEQABixAxiABDIKCAIQABixAxiABDIKCAMQABixAxiABDINCAQQABixAxiABBiKBTIKCAUQABixAxiABDIKCAYQABixAxiABDIHCAcQABiABDINCAgQABiDARixAxiABDIQCAkQABiDARixAxiABBiKBdIBCTYxNjdqMGoxNagCALACAA&sourceid=chrome&ie=UTF-8" );
        return "home"; // This will resolve to src/main/resources/templates/home.html
    }
    @RequestMapping("/about")
    public String aboutPage(Model model)
    {
        model.addAttribute("isLogin",true );
        System.out.println("about page handler");
        return "about";
    }
    @RequestMapping("/services")
    public String servicesPage()
    {
        System.out.println("service page handler");
        return "services";
    }

    @GetMapping("/contact")
    public String contact() {
        return new String("contact");
    }
    //This is login  page
    @GetMapping("/login")
    public String login() {
        return new String("login");
    }
    //This is registration page
    @GetMapping("/register")
    public String register(Model model) {
        UserForm userForm = new UserForm();
        // userForm.setName("Girija");
        // userForm.setEmail("girija@gmail.com");
        // userForm.setPassword("password");
        // userForm.setAbout("I am a software engineer");
        model.addAttribute("userForm", userForm);
        return new String("register");
    }
    //processig regsiter**
   @RequestMapping(value="/do-register", method=RequestMethod.POST)
   public String processRegister(@Valid @ModelAttribute UserForm userForm,BindingResult rBindingResult, HttpSession session) {
      System.out.println("Processing register"); 
      //fetch form data
      //print userform
      System.out.println(userForm);
      if(rBindingResult.hasErrors())
      {
        return "register"; // Redirect to the register page with error message
      }
    //   User user = User.builder()
    //             .name(userForm.getName())
    //             .email(userForm.getEmail())
    //             .password(userForm.getPassword())
    //             .about(userForm.getAbout())
    //             .phoneNumber(userForm.getPhoneNumber())
    //             .profilePic(
    //                 "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.freepik.com%2Ffree-photos-vectors%2Fdefault-user&psig=AOvVaw0R9zzHnEAZBBMiCOhWegxK&ust=1745697729720000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCOCxvPr884wDFQAAAAAdAAAAABAJ"
    //             )
    //             .build();
    User user = new User();
    user.setName(userForm.getName());
    user.setEmail(userForm.getEmail()); 
    user.setPassword(userForm.getPassword());
    user.setAbout(userForm.getAbout());
    user.setPhoneNumber(userForm.getPhoneNumber());
    user.setProfilePic(
        "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.freepik.com% ");
      
        user.setProvider(Providers.SELF);
        user.setEnabled(true);              // if you want the account enabled on registration
        user.setEmailVerified(false);      // you can set this later after verification
        user.setPhoneVerified(false);  
        User savedUser =  userService.saveUser(user);
        System.out.println("User saved: " );
        //show message
        Message message =  Message.builder().content("Registration successful!").type(MessageType.green).build();
        session.setAttribute("message", message);
    return "redirect:/register"; // Redirect to the register page with success message
   }
        
}
