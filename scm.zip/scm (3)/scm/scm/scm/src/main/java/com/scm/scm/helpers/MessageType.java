package com.scm.scm.helpers;

public enum MessageType {
    blue,red,green,yellow
}
