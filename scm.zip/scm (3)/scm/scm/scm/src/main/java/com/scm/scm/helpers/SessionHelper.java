package com.scm.scm.helpers;

import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpSession;

@Component
public class SessionHelper {

    public static void removeMessage()
    {
        try{
            System.out.println("Session is available");
        HttpSession session = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession();
        session.removeAttribute("message");
        }
        catch (Exception e)
        {
            System.out.println("Session is not available" +e);
            e.printStackTrace();
        }
    }
}
